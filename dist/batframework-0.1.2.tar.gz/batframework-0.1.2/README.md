# Example Package

Pygame framework for making games easier.
